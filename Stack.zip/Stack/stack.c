#include<stdio.h>
void push(int data);
void pop();
int N=5;
int top=-1;
int st[5];
void main()
{   
    push(5);
    push(7);
    push(8);
    for ( int i = 0; i <= top; i++)
    {
        printf("\nArray is %d ", st[i]);
    }
    pop();
    pop();
    printf("\n\nAfter Pop array is---");
     for ( int i = 0; i <= top; i++)
    {
        printf("\nArray is %d ", st[i]);
    }

}
void push(int data){
    if(top==N-1){
        printf("Overflow");
    }
    else{
        top=top+1;
        st[top]=data;
        
        
    }
}
void pop(){
    if(top == -1){
        printf("Underflow");
    }
    else{
        top=top-1;
    }

}